package Refactoring;

public class SurfaceBook {
	private final static String OP_SYS_TYPE = "Windows OS";

	private String ownerName;
	private double currentOpSysVersion;	

	// ------------------------------------------------------------------------

	public SurfaceBook(String ownerName, double currentOpSysVersion) {
		this.ownerName = ownerName;
		this.currentOpSysVersion = currentOpSysVersion;	
	} // SurfaceBook

	// ------------------------------------------------------------------------

	public void generateOwnerReport() {
		System.out.printf("|%.50s|\n", "++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.printf("|%.50s|\n", "++++++++++++ EIT Servicing Surfaces ++++++++++");
		System.out.printf("|%.50s|\n", "                                              ");
		System.out.printf("|%.50s|\n", "                                              ");
		System.out.printf("|     %10s%.1f      %-10s            |\n", OP_SYS_TYPE, this.currentOpSysVersion, this.ownerName);
		System.out.printf("|%.50s|\n", "                                              ");
		System.out.printf("|%.50s|\n", "                                              ");
		System.out.printf("|%.50s|\n", "+++++++++++++++++ End Report +++++++++++++++++");
		System.out.printf("|%.50s|\n\n\n", "++++++++++++++++++++++++++++++++++++++++++++++");
	} // generateOwnerReport

	// ------------------------------------------------------------------------

	public double getCurrentOpSysVersion() {
		return this.currentOpSysVersion;
	} // getCurrentOpSysVersion

	// ------------------------------------------------------------------------

	public String getOwnerName() {
		return this.ownerName;
	} // getOwnerName

} // SurfaceBook
