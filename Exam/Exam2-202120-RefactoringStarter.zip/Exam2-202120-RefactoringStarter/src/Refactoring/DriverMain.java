package Refactoring;

import java.util.ArrayList;
import java.util.List;

/**
 * This program features laptops
 * 
 * Your job is to use inheritance with a class or inheritance with an
 * abstract class to remove as much code duplication as you can
 * from the 3 laptop classes (ChromeBook, MacBook, SurfaceBook) and
 * the main program (below)
 * 
 * @author --- put your name here ---
 *
 */
public class DriverMain {

	public static void main(String[] args) {
		List<ChromeBook> cBooks = new ArrayList<ChromeBook>();
		List<MacBook> mBooks = new ArrayList<MacBook>();
		List<SurfaceBook> sBooks = new ArrayList<SurfaceBook>();

		// ------------------------------------------------------------------------
		
		// ----------------
		// Add ChromeBooks
		// ----------------
		cBooks.add(new ChromeBook("Prof Yoder", 2.1));

		// ----------------
		// Add MacBooks
		// ----------------
		mBooks.add(new MacBook("Prof Boutell", 9.8));
		mBooks.add(new MacBook("Prof Wilkin", 10.0));

		// ----------------
		// Add SurfaceBooks
		// ----------------
		sBooks.add(new SurfaceBook("Prof Mohan", 5.5));

		// ------------------------------------------------------------------------
		
		// ----------------
		// Generate Reports
		// ----------------
		for (ChromeBook cBook : cBooks) {
			cBook.generateOwnerReport();
		} // end for

		for (MacBook mBook : mBooks) {
			mBook.generateOwnerReport();
		} // end for

		for (SurfaceBook sBook : sBooks) {
			sBook.generateOwnerReport();
		} // end for

		// ------------------------------------------------------------------------
		
		// ----------------
		// Generate List of All Owner Names
		// ----------------
		for (ChromeBook cBook : cBooks) {
			System.out.println(cBook.getOwnerName());
		} // end for

		for (MacBook mBook : mBooks) {
			System.out.println(mBook.getOwnerName());
		} // end for

		for (SurfaceBook sBook : sBooks) {
			System.out.println(sBook.getOwnerName());
		} // end for
		
	} // main

} // DriverMain