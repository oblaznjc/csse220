package refactoring;

import java.util.ArrayList;
import java.util.List;

public class PizzaStoreDriver {
	
	public static void handleOrder(int numCheesePizzas, int numClamPizzas, int numPepperoniPizzas) {
		
		List<CheesePizza> cheesePizzas = new ArrayList<CheesePizza>();
		List<ClamPizza> clamPizzas = new ArrayList<ClamPizza>();
		List<PepperoniPizza> pepperioniPizzas = new ArrayList<PepperoniPizza>();
		

		System.out.println("======================================================");
		System.out.println("==================== Making Pizzas ===================");
		System.out.println("======================================================");
		
		// Make Cheese pizzas
		for (int k = 0; k < numCheesePizzas; k++) {
			CheesePizza pizza = new CheesePizza();
			pizza.order();
			cheesePizzas.add(pizza);
		} // end for
		
		// Make Clam pizzas
		for (int k = 0; k < numClamPizzas; k++) {
			ClamPizza pizza = new ClamPizza();
			pizza.order();
			clamPizzas.add(pizza);
		} // end for
		
		// Make Pepperoni pizzas
		for (int k = 0; k < numPepperoniPizzas; k++) {
			PepperoniPizza pizza = new PepperoniPizza();
			pizza.order();
			pepperioniPizzas.add(pizza);
		} // end for
		

		System.out.println("======================================================");
		System.out.println("==================== Pizzas Made =====================");
		System.out.println("======================================================");
		
	}

	public static void main(String[] args) {	
		int numCheeses = 2;
		int numClams = 1;
		int numPepperonis = 2;
		handleOrder(numCheeses, numClams, numPepperonis);
	}

}
