package refactoring;

import java.util.ArrayList;
import java.util.List;

public class ClamPizza  {
	
	private String pizzaName;
	private List<String> toppingsList;

	// -----------------------------------------------------------
	
	public ClamPizza() {
		this.pizzaName = "Clam";
		this.toppingsList = new ArrayList<String>();
	} // ClamPizza
		
    public void bake() {
        System.out.println("Baking pizza: Pepperoni");
    } // bake
    
    public void cut() {
        System.out.println("Cutting pizza: Pepperoni");
    } // cut
    
    public void box() {
        System.out.println("Boxing pizza: Pepperoni");
    } // box

    public void prepare () {
        System.out.println("Preparing pizza: " + this.pizzaName);
        this.toppingsList.add("traditional crust");
        this.toppingsList.add("red sauce");
        this.toppingsList.add("cheese");
        this.toppingsList.add("clams");
    } // prepare
    
    public void order() {
    	this.prepare();
    	this.bake();
    	this.cut();
    	this.box();    	
    } // order
    
    public String getPizzaName() {
        return pizzaName;
    } // getPizzaName
    
} // end class
