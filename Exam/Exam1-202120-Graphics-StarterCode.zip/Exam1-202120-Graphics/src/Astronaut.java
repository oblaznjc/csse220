import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;

public class Astronaut {
	
	// ------
	// CONSTANTS	
	// ------
	private static final int HEIGHT_TO_WIDTH_RATIO = 2;  //i.e.  if height=100, then width=50
	private static final int BORDER_WIDTH = 10;
	private static final Color OUTLINE_COLOR = Color.BLACK;
	
	// ------
	// Default values for Astronaut	
	// ------
	private static final int DEFAULT_HEIGHT = 100;
	private static final int DEFAULT_CENTER_X = 80;
	private static final int DEFAULT_CENTER_Y = 80;
	private static final Color DEFAULT_COLOR = new Color(0,155,0);
	
	// ------
	// TODO: Add instance variables
	// ------


	// ------
	// TODO: Add constructors
	// ------


	

	/**
	 * 
	 * @param g2d 
	 */
	private void drawAstronaut(Graphics2D g2d) {
		// ------
		// Provided code - set the stroke size, so that outlines are thick
		// ------
		g2d.setStroke(new BasicStroke( BORDER_WIDTH ));  // This does not need to be changed
		
		
		//You will want to change the code below 
		//You may want to comment it out for now and then use as a reference.
		//This code calculates a location and draws the "suit" for the default Astronaut
		
		//            50 = 100            / 2 
		int defaultWidth = DEFAULT_HEIGHT / HEIGHT_TO_WIDTH_RATIO;
		
		//          55 = 80              - 50            / 2
		int upperLeftX = DEFAULT_CENTER_X - defaultWidth / 2;
		
		//          30 = 80               - 100            / 2
		int upperLeftY = DEFAULT_CENTER_Y - DEFAULT_HEIGHT / 2;

		//Draw Outline for suit
		g2d.drawOval(upperLeftX, upperLeftY, defaultWidth, DEFAULT_HEIGHT);
		
		//Draw Filled Oval for suit
		g2d.setColor( DEFAULT_COLOR );
		g2d.fillOval(upperLeftX, upperLeftY, defaultWidth, DEFAULT_HEIGHT);
		
		//end Provided code
		
		
		
		// ------
		// TODO: #1: Move pen to a proper position to draw astronaut
		// ------
		
		
		// ------
		// For Part 3 
		// TODO: Calculate position of "LEFT"/"RIGHT" orientation for
		//       a) backpack position
		//       b) visor position
		// ------
		
		
	    // -----
		// TODO: #2 Draw the backpack 
		//          (centered horizontally on left/right side of suit's bounding rectangle)
		//          1/2 full width
		//          1/2 full height
	    // -----	


	    // -----
		// TODO: #3 Draw the suit
		//          full width
		//          full height
	    // -----	
		
		
	    // -----
		// TODO: #4 Draw the visor (looks like a face shield)
		//		    aligned to be even with left/right side of suit's bounding rectangle
		//          3/4 full width 
		//          1/8 full height
	    // -----	
		
		
	    // -----
		// TODO: If necessary, reset the 'g2d' graphics context back to its original settings
	    // -----

	 
		
	} // drawAstronaut
	
	public void drawOn(Graphics2D g2d) {
		drawAstronaut(g2d);
	} // drawOn
	

}
