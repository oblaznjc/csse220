package graphics;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Polygon;
import java.awt.Stroke;

/**
 * This class represents a single brush stroke starting from one location and moving to another.
 * It also have a particular color and stroke size.
 * 
 * @author your username
 *
 */
public class BrushStroke {
	
	// ------
	// TODO: Add instance variables
	// ------

	
	// ------
	// TODO: Add constructors
	// ------


	/**
	 * 
	 * @param g2d 
	 */
	public void drawOn(Graphics2D g2d) {

		
	} // drawOn
	


}
